package fr.eni.tp.filmotheque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmothequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
