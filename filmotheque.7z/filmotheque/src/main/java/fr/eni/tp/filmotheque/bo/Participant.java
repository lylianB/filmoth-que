package fr.eni.tp.filmotheque.bo;

public class Participant extends Personne {
	
	
/**
 *  constructeur par defaut	
 */

	public Participant() {
		super();
	}

	/** 
	 * constructeur
	 * @param id
	 * @param nom
	 * @param prenom
	 */
	public Participant(long id, String nom, String prenom) {
		super(id, nom, prenom);
	}

    /**
     * constructeur
     * @param nom
     * @param prenom
     */
	public Participant(String nom, String prenom) {
		super(nom, prenom);
	}
	
	
	
	

}
