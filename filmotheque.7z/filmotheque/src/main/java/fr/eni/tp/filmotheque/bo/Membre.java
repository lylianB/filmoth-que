package fr.eni.tp.filmotheque.bo;

public class Membre extends Personne {

	private String  pseudo;
	private String  motDePasse;
	private boolean admin      = false;
	
	
/**
 * constructeur par defaut	
 */
public Membre() {
		super();
	}



/**
 * constructeur	
 * @param id
 * @param nom
 * @param prenom
 * @param pseudo
 * @param motDePasse
 * @param admin
 */
	public Membre(long id, String nom, String prenom, String pseudo, String motDePasse) {
		super(id, nom, prenom);
		this.pseudo = pseudo;
		this.motDePasse = motDePasse;		
	}



	public Membre(String nom, String prenom, String pseudo, String motDePasse) {
		super(nom, prenom);
		this.pseudo = pseudo;
		this.motDePasse = motDePasse;		
	}


// getter & setter
	public String getPseudo() {
		return pseudo;
	}



	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}



	public String getMotDePasse() {
		return motDePasse;
	}



	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}



	public boolean isAdmin() {
		return admin;
	}



	public void setAdmin(boolean admin) {
		this.admin = admin;
	}



	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Membre [pseudo=");
		builder.append(pseudo);
		builder.append(", admin=");
		builder.append(admin);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
	
	

	
	
	
	
	
	
	
	

}
