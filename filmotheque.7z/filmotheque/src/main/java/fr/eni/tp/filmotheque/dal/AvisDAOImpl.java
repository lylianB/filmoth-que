package fr.eni.tp.filmotheque.dal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import fr.eni.tp.filmotheque.bo.Avis;
import fr.eni.tp.filmotheque.bo.Membre;

@Service
public class AvisDAOImpl implements AvisDAO {
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	
	private static final String FIND_BY_FILM = "SELECT a.id AS idavis, note, commentaire, id_membre, nom, prenom, email, password, admin FROM avis AS a INNER JOIN membre As m on a.id_membre = m.id where a.id_film = :id_film";
	

	public AvisDAOImpl(NamedParameterJdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void create(Avis avis, long idFilm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Avis> findByFilm(long idFilm) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id_film",idFilm);
		
		return jdbcTemplate.query(FIND_BY_FILM, mapParameterSource, new AvisRowMapper());
	}
	/**
	 * Mise en place du RowMapper avec gestion de l'association 1-1
	 */
	class AvisRowMapper implements RowMapper<Avis> {

		@Override
		public Avis mapRow(ResultSet rs, int rowNum) throws SQLException {
					
			
			Avis a = new Avis();
			a.setId(rs.getInt("idavis"));
            a.setNote(rs.getInt("note"));
            a.setCommentaire(rs.getString("commentaire"));
         
            
         // Association avis membre
            Membre m = new Membre();
            
            m.setId(rs.getInt("id_membre"));
            m.setNom(rs.getString("nom"));
            m.setPrenom(rs.getString("prenom"));
            m.setPseudo(rs.getString("email"));
//          m.setMotDePasse(rs.getString("password"));
            m.setMotDePasse(null);
            m.setAdmin(rs.getBoolean("admin"));
            
            a.setMembre(m);
			
						
			System.out.println("sortie map row : " + a);
			
			
			return a;
		}
	}
}
