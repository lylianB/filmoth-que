package fr.eni.tp.filmotheque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import fr.eni.tp.filmotheque.bll.ContexteService;
import fr.eni.tp.filmotheque.bo.Membre;


@Controller
@SessionAttributes("contexteAttribut")
public class ContexteController {
	private ContexteService contexteService;
	
	
	private static final String CONTEXTE = "view-context";

	
	public ContexteController(ContexteService contexteService) {		
		this.contexteService = contexteService;
	}

	@GetMapping("/films/Contexte")
	public String afficherContext() {
		System.out.println("AfficherContexte  " );
		return CONTEXTE;
	}

	@GetMapping("/films/context/session")
	public String verifierContexte(@RequestParam(name="email", 
												 required = false,
												 defaultValue = "jtrillard@campus-eni.fr" ) String email,
								   @ModelAttribute("contexteAttribut") Membre membreSession ) {
		System.out.println("email :  " + email);
		Membre membre =contexteService.charger(email); 
		
		if (membre != null) {
			// mettre à jour membreSession avec le membre chargé
			membreSession.setId(membre.getId());
			membreSession.setNom(membre.getNom());
			membreSession.setPrenom(membre.getPrenom());
			membreSession.setAdmin(membre.isAdmin());
			membreSession.setPseudo(membre.getPseudo());
			System.out.println("remplissage");
		} else {
			membreSession.setId(0);
			membreSession.setNom(null);
			membreSession.setPrenom(null);
			membreSession.setAdmin(false);
			membreSession.setPseudo(null);
		}
		
		System.out.println( "membreSession : " + membreSession + membreSession.getId());
		return "redirect:/films";
	}
	
	@GetMapping("/films/context/cloture")
	public String finSession(SessionStatus sessionStatus) {
		System.out.println("destruction session");
		sessionStatus.setComplete();
		
		return "redirect:/films";
	}

	
	@ModelAttribute("contexteAttribut")
	public Membre chargerMembre () {
		System.out.println(" chargement contexte de session : "  );		
		return  new Membre();
	}
	
}
