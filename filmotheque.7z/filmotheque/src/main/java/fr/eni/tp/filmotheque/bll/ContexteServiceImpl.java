package fr.eni.tp.filmotheque.bll;

import org.springframework.stereotype.Service;

import fr.eni.tp.filmotheque.bo.Membre;
import fr.eni.tp.filmotheque.dal.MembreDAO;

@Service
public class ContexteServiceImpl implements ContexteService {
	MembreDAO membreDAO;
	
	

	public ContexteServiceImpl(MembreDAO membreDAO) {		
		this.membreDAO = membreDAO;
	}



	@Override
	public Membre charger(String email) {
		System.out.println("charger membre : " + membreDAO.read(email));
		return membreDAO.read(email);
	}

}
