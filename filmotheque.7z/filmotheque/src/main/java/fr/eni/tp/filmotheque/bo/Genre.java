package fr.eni.tp.filmotheque.bo;

import java.io.Serializable;
import java.util.Objects;

public class Genre implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String titre;
	
		
public Genre() {
		
	}

/**
 * constructeur	
 * @param id
 * @param titre
 */
public Genre(long id, String titre) {		
		this.id = id;
		this.titre = titre;
	}



/**
 * constructeur
 * @param titre
 */
public Genre(String titre) {
	this(0,titre);
	
}

// getter & setter	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}

/**
 * methode toString
 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Genre [id=");
		builder.append(id);
		builder.append(", titre=");
		builder.append(titre);
		builder.append("]");
		return builder.toString();
	}



@Override
public int hashCode() {
	return Objects.hash(id);
}


/**
 * equals sur id
 */
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Genre other = (Genre) obj;
	return id == other.id;
}
	
	
	
	

}
