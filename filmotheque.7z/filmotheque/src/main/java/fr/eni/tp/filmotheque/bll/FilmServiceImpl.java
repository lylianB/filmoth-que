package fr.eni.tp.filmotheque.bll;

import java.util.List;

import org.springframework.stereotype.Service;

import fr.eni.tp.filmotheque.bo.Avis;
import fr.eni.tp.filmotheque.bo.Film;
import fr.eni.tp.filmotheque.bo.Genre;
import fr.eni.tp.filmotheque.bo.Participant;
import fr.eni.tp.filmotheque.dal.AvisDAO;
import fr.eni.tp.filmotheque.dal.FilmDAO;
import fr.eni.tp.filmotheque.dal.GenreDAO;
import fr.eni.tp.filmotheque.dal.GenreDaoImpl;
import fr.eni.tp.filmotheque.dal.ParticipantDAO;
import fr.eni.tp.filmotheque.dal.ParticipantDAOImpl;

@Service
public class FilmServiceImpl implements FilmService {
	private FilmDAO filmDAO;
	private GenreDAO genreDAO;
	private ParticipantDAO participantDAO;
	private AvisDAO avisDAO;
	

	public FilmServiceImpl(FilmDAO filmDAO, GenreDAO genreDAO, ParticipantDAO participantDAO, AvisDAO avisDAO) {
		super();
		this.filmDAO = filmDAO;
		this.genreDAO = genreDAO;
		this.participantDAO = participantDAO;
		this.avisDAO = avisDAO;
	}

	@Override
	public List<Film> consulterFilms() {
		List<Film> films = filmDAO.findAll();
		
		films.forEach(f -> { f.setGenre(genreDAO.read(f.getId()));
		                     f.setRealisateur(participantDAO.read(f.getId()));                       
		});
		return films;
	//	return filmDAO.findAll();
	}

	@Override
	public Film consulterFilmParId(long id) {	
		Film f = filmDAO.read(id);
		// recupere la liste des acteurs du film
		List<Participant> acteurs = participantDAO.findacteurs(id);
		
		System.out.println("acteurs " + acteurs);
		
		if (acteurs !=null) {
			f.setActeurs(acteurs);
		}
		
		List<Avis> listeAvis = avisDAO.findByFilm(id);
		
		
		if (listeAvis !=null) {
			f.setAvis(listeAvis);
		}
		
		System.out.println("consulterFilmParId : " + f);
		return f;		
		
	}

	@Override
	public List<Genre> consulterGenres() {
		
		return genreDAO.findAll();
	}

	@Override
	public List<Participant> consulterParticipants() {
		// TODO Auto-generated method stub
		return participantDAO.findAll();
	}

	@Override
	public Genre consulterGenreParId(long id) {
		
		return genreDAO.read(id);
	}

	@Override
	public Participant consulterParticipantParId(long id) {
		return participantDAO.read(id);
	}

	@Override
	public void creerFilm(Film film) {
		filmDAO.create(film);
		
	}

	@Override
	public String consulterTitreFilm(long id) {		
		return filmDAO.findTitre(id);
	}

	@Override
	public void publierAvis(Avis avis, long idFilm) {
	 avisDAO.create(avis,idFilm);
		
	}

	@Override
	public List<Avis> consulterAvis(long idFilm) {
		// TODO Auto-generated method stub
		return null;
	}

}
