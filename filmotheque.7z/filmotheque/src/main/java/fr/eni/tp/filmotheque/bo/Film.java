package fr.eni.tp.filmotheque.bo;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class Film {

	private long   id;
	@NotBlank(message = "Le titre doit être renseigné") 
	@Size(max=250, message="Le titre a un maximum de 250 caracteres")
	private String titre;
	@Min(value = 1900, message = "L' année de sortie doit etre au minimum de 1900" )
	private int    annee;
	@Min(value = 1 , message = " La durée est obligatoire" )
	@Digits( fraction = 0, integer = 4, message ="La durée doit etre un entier" ) 
	private int    duree ;
	@NotBlank(message = "le synopsis doit etre renseigné" )
	@Size(min =20, max=250, message="Le titre doit faire entre 20 et 250 caracteres")
	private String synopsis;
	
	private Genre genre;
	
	private List<Avis>        avis ;	
	private Participant       realisateur;
	private List<Participant> acteurs;

	
	
/**
 * constructeur par defaut	
 */
	
public Film() {
		
	}

/**
 * constructeur	
 * @param id
 * @param titre
 * @param annee
 * @param duree
 * @param synopsis
 */
	
	public Film(long id, String titre, int annee, int duree, String synopsis) {
		this.id       = id;
		this.titre    = titre;
		this.annee    = annee;
		this.duree    = duree;
		this.synopsis = synopsis;
		avis   = new ArrayList<Avis>();
		acteurs = new ArrayList<Participant>();
	}

/**
 * constructeur	
 * @param titre
 * @param annee
 * @param duree
 * @param synopsis
 */
	public Film(String titre, int annee, int duree, String synopsis) {
		this(0,titre, annee,duree,synopsis);
	
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
	this.id = id;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public int getAnnee() {
		return annee;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}
	
	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	public List<Avis> getAvis() {
		return avis;
	}

	public void setAvis(List<Avis> aviss) {
		this.avis = aviss;
	}

	public Participant getRealisateur() {
		return realisateur;
	}

	public void setRealisateur(Participant realisateur) {
		this.realisateur = realisateur;
	}

	public List<Participant> getActeurs() {
		return acteurs;
	}

	public void setActeurs(List<Participant> acteurs) {
		this.acteurs = acteurs;
	}

/**
 *  methode to String	
 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Film [id=");
		builder.append(id);
		builder.append(", titre=");
		builder.append(titre);
		builder.append(", annee=");
		builder.append(annee);
		builder.append(", duree=");
		builder.append(duree);
		builder.append(", synopsis=");
		builder.append(synopsis);
		builder.append(", genre=");
		builder.append(genre);
		builder.append(", avis=");
		builder.append(avis);
		builder.append(", realisateur=");
		builder.append(realisateur);
		builder.append(", acteurs=");
		builder.append(acteurs);
		builder.append("]");
		return builder.toString();
		
	}

@Override
public int hashCode() {
	return Objects.hash(id);
}

/**
 *  equals sur id
 */
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Film other = (Film) obj;
	return id == other.id;
}
	
	
	
	
}
