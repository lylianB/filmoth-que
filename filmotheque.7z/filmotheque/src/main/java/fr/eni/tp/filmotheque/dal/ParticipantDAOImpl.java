package fr.eni.tp.filmotheque.dal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import fr.eni.tp.filmotheque.bo.Participant;

@Repository
public class ParticipantDAOImpl implements ParticipantDAO {
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	
	
	public static final String FIND_ACTEUR = "SELECT id_film , id_participant, nom, prenom FROM ACTEURS AS a INNER JOIN participant as p on a.id_participant = p.id where a.id_film = :id_film";
    public static final String READ        = "SELECT id, nom, prenom FROM PARTICIPANT WHERE id = :id"; 
		
	public ParticipantDAOImpl(NamedParameterJdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Participant read(long id) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id",id);
		return jdbcTemplate.queryForObject(READ,mapParameterSource,new BeanPropertyRowMapper<>(Participant.class));
		
	}

	@Override
	public List<Participant> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Participant> findacteurs(long idFilm) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id_film",idFilm);
		
		return jdbcTemplate.query(FIND_ACTEUR, mapParameterSource, new FilmRowMapper());
	}

	@Override
	public Void createActeur(long idParticipant, long idFilm) {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * Mise en place du RowMapper avec gestion de l'association 1-1
	 */
	class FilmRowMapper implements RowMapper<Participant> {

		@Override
		public Participant mapRow(ResultSet rs, int rowNum) throws SQLException {
					
			
			Participant p = new Participant();
			p.setId(rs.getInt("id_participant"));
			p.setNom(rs.getString("nom"));
			p.setPrenom(rs.getString("prenom"));
			
						
			System.out.println("sortie map row : " + p);
			
			
			return p;
		}
	}
}
