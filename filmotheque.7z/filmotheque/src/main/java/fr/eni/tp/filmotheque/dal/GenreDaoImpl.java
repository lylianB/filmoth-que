package fr.eni.tp.filmotheque.dal;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;


import fr.eni.tp.filmotheque.bo.Genre;

@Repository
public class GenreDaoImpl implements GenreDAO {
	private static final String READ     = "SELECT id , titre FROM genre WHERE id = :id";
	private static final String FIND_ALL = "SELECT id , titre FROM genre";
	
	
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	
	
	
	public GenreDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}
/**
 *  select by id
 */
	@Override
	public Genre read(long id) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id",id);
		
		return jdbcTemplate.queryForObject(READ, mapParameterSource, new BeanPropertyRowMapper<>(Genre.class));
		
	}

/**
 * select
 */
	@Override
	public List<Genre> findAll() {
		return jdbcTemplate.query(FIND_ALL, new BeanPropertyRowMapper<>(Genre.class));
	}

}
