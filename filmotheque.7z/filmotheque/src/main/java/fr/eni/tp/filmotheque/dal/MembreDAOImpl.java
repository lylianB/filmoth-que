package fr.eni.tp.filmotheque.dal;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import fr.eni.tp.filmotheque.bo.Membre;
import fr.eni.tp.filmotheque.bo.Participant;

@Repository
public class MembreDAOImpl implements MembreDAO {
	
	private NamedParameterJdbcTemplate jdbcTemplate;
	
	private static final String READ_BY_ID = "SELECT id, nom, prenom, email, admin FROM MEMBRE WHERE id = :id";
	private static final String READ_BY_EMAIL = "SELECT id, nom, prenom, email, admin FROM MEMBRE WHERE email =:email";
	

	public MembreDAOImpl(NamedParameterJdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Membre read(long id) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id",id);
		return jdbcTemplate.queryForObject(READ_BY_ID,mapParameterSource,new BeanPropertyRowMapper<>(Membre.class));
		
	}

	@Override
	public Membre read(String email) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("email",email);
		return jdbcTemplate.queryForObject(READ_BY_EMAIL,mapParameterSource,new BeanPropertyRowMapper<>(Membre.class));
		
	}

}
