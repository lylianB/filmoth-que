package fr.eni.tp.filmotheque.controller.convertor;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import fr.eni.tp.filmotheque.bll.FilmService;
import fr.eni.tp.filmotheque.bo.Genre;



@Component
public class StringToGenreConvertor implements Converter<String, Genre> {
	
	private FilmService filmService;
	
	
	
	public StringToGenreConvertor(FilmService filmService) {
		this.filmService = filmService;
	}


	@Override
	public Genre convert(String idGenre) {
		
		return filmService.consulterGenreParId(Long.parseLong(idGenre));
		
	
	}

}
