package fr.eni.tp.filmotheque.controller.convertor;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import fr.eni.tp.filmotheque.bll.FilmService;
import fr.eni.tp.filmotheque.bo.Participant;
	
	/**
	 *  le converter sera appelé afin d' injecter un cours
	 *  dans une liste de cours du formateur
	 */
	@Component
public class StringToParticipantConvertor implements Converter<String, Participant> {	
		private FilmService filmService;
		
		
		
		public StringToParticipantConvertor(FilmService filmService) {
			this.filmService = filmService;
		}


		@Override
		public Participant convert(String idParticipant) {
			
			return filmService.consulterParticipantParId(Long.parseLong(idParticipant));
			
		
		}

		
		
}
	

