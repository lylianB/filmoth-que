package fr.eni.tp.filmotheque.controller;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import fr.eni.tp.filmotheque.bll.FilmService;
import fr.eni.tp.filmotheque.bo.Film;
import fr.eni.tp.filmotheque.bo.Genre;
import fr.eni.tp.filmotheque.bo.Participant;
import jakarta.validation.Valid;


@Controller
@RequestMapping("/films")
@SessionAttributes({"listeGenre", "listeParticipant", "contexteAttribut" })
public class FilmController {
	private FilmService filmService;
	
	private static final String LISTFILMS = "view-films";
	private static final String DETAILFILM = "view-film-detail";
	private static final String CREERFILM = "view-film-creation";
	
	// injection de dependance par constructeur	
	public FilmController( FilmService filmService ) {
		this.filmService = filmService;
	}

	
/**
 * methode permettant d' afficher la liste des films	
 * @param model
 * @return
 */
@GetMapping	
	public String afficherListeFilms(Model model) {
	 List<Film> films = this.filmService.consulterFilms();
	 model.addAttribute("films", films);
	 return LISTFILMS;
			
		
	}
/**
 * methode permettant d' afficher le detail d' un film
 */
@GetMapping("/detail")	
	public String afficherUnFilm(@RequestParam(name="id")long id, Model model) {
		System.out.println(filmService.consulterFilmParId(id));
		Film film = filmService.consulterFilmParId(id);		
		model.addAttribute("film", film);

//faire la liste des acteurs pour l' affichage		
		String chaine= "";
		for (Participant acteur  : film.getActeurs()) {
			chaine = chaine + acteur.getPrenom() + " " + acteur.getNom() + "\n";
		}
		model.addAttribute("chaine", chaine);
				
		return DETAILFILM;
	}

@GetMapping("/creer")
	public String creerFilm (Model model) {
		// etape 1 : création d' une instance de film
		Film film = new Film();
		// Etape 2 : placer le film dans le model
		model.addAttribute("film", film);
		// Etape 3 envoyer la map
	   return CREERFILM;
}



@PostMapping("/creer")
	public String creerFormateur (@Valid @ModelAttribute("film") Film film,
			BindingResult bingingResult) {
	
	    System.out.println(" post mapping creer");
		System.out.println(bingingResult.hasErrors());
	   // pour afficher les erreur , il faut renvoyer la map
	    if (bingingResult.hasErrors()) {
	    	return CREERFILM;
	    }
	    	
	
		System.out.println("création film = " + film);
		
		// insertion du film
		this.filmService.creerFilm(film);
		
		// redirection vers la list de film
		return "redirect:/films";
}

@ModelAttribute("listeGenre")
  public List<Genre> listeGenre () {
	System.out.println(" chargement Contexte de session : " + filmService.consulterGenres() );
	return filmService.consulterGenres();
	
	}

@ModelAttribute("listeParticipant")
public List<Participant> listeParticipant () {
	System.out.println(" chargement Contexte de session : " + filmService.consulterParticipants() );
	return filmService.consulterParticipants();
	
	}



}
