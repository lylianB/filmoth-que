package fr.eni.tp.filmotheque.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.eni.tp.filmotheque.bll.FilmService;
import fr.eni.tp.filmotheque.bo.Avis;
import fr.eni.tp.filmotheque.bo.Membre;


@Controller
@RequestMapping("/films")
@SessionAttributes("contexteAttribut")
public class AvisController {
	private FilmService filmService;
	
	private static final String CREERAVIS = "view-avis";

/**
 * constructeur pour injecter FilmService	
 * @param filmService
 */
	public AvisController(FilmService filmService) {
		
		this.filmService = filmService;
	}
	
	@GetMapping("/avis")	
	public String afficherAvis( @ModelAttribute("contexteAttribut") Membre membre,
			                    @RequestParam(name="id")long id, Model model) {	
		
		// pour empecher un petit malin qui connait l' URL de la saisir sans etre admin
	//	if (!membre.isAdmin()) {
	//		return "redirect:/films";
	//	}
				
		System.out.println("affichage view avis");
		// etape 1 : création d' une instance d' avis
		Avis avis = new Avis();
		// Etape 2 : placer l' avis dans le model
				model.addAttribute("avis", avis);
		// Etape 2 bis : placer le Film dans un model
				model.addAttribute("film", filmService.consulterFilmParId(id));
		// Etape 3 envoyer la map	
				
		return CREERAVIS;
	}
	
	@PostMapping("/avis")
	public String creerAvis (@ModelAttribute("avis") Avis avis, 
			                 @ModelAttribute("contexteAttribut") Membre membre,
							@RequestParam(name="filmId") long filmId ) {
		System.out.println("création avis = " + avis);			
		// mettre le membre dans l' avis
		avis.setMembre(membre);
		System.out.println("création avis = " + avis);	
		
		// creation avis
		this.filmService.publierAvis(avis, filmId);
		
		System.out.println(filmService.consulterFilmParId(filmId));
		
		// redirection vers la list de film
		return "redirect:/films";
	}	

}
