package fr.eni.tp.filmotheque.dal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import fr.eni.tp.filmotheque.bo.Film;
import fr.eni.tp.filmotheque.bo.Genre;
import fr.eni.tp.filmotheque.bo.Participant;

@Repository
public class FilmDaoImpl implements FilmDAO {
	
	public final static String CREATE      = "INSERT INTO FILM (titre,annee,duree,synopsis,id_realisateur,id_genre) VALUES (:titre,:année,:duree,:synopsis,:id_realisateur,:id_genre)";
	public final static String READ        = "SELECT f.id AS id_film, f.titre,annee,duree,synopsis,id_realisateur,id_genre,g.titre AS titre_genre, p.id AS id_realisateur, nom, prenom FROM FILM AS f INNER JOIN genre AS g ON f.id = g.id INNER JOIN participant AS p on id_realisateur = p.id WHERE f.id = :id";
//	public final static String FIND_ALL    = "SELECT f.id AS id_film, f.titre,annee,duree,synopsis,id_realisateur,id_genre,g.titre AS titre_genre, p.id AS id_realisateur, nom, prenom FROM FILM AS f INNER JOIN genre AS g ON f.id = g.id INNER JOIN participant AS p on id_realisateur = p.id";
	public final static String FIND_ALL    = "SELECT id, titre, annee, duree, synopsis, id_realisateur, id_genre FROM FILM";
	public final static String FIND_TITRE  = "SELECT titre FROM FILM WHERE id = :id";
	
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	
	

	public FilmDaoImpl(NamedParameterJdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void create(Film film) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("titre",film.getTitre());
		mapParameterSource.addValue("annee",film.getAnnee());
		mapParameterSource.addValue("duree",film.getDuree());
		mapParameterSource.addValue("id_realisateur",film.getRealisateur().getId());
		mapParameterSource.addValue("id_genre",film.getGenre().getId());
		
		jdbcTemplate.update(CREATE, mapParameterSource);
		
	}

	@Override
	public Film read(long id) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id",id);
		return jdbcTemplate.queryForObject(READ, mapParameterSource, new FilmRowMapper());
	}

	@Override
	public List<Film> findAll() {		
//		List<Film> films = jdbcTemplate.query(FIND_ALL, new FilmRowMapper());
//		return films;
		return jdbcTemplate.query(FIND_ALL , new BeanPropertyRowMapper<>(Film.class));
	}

	@Override
	public String findTitre(long id) {
		MapSqlParameterSource mapParameterSource = new MapSqlParameterSource();
		mapParameterSource.addValue("id",id);
		return (jdbcTemplate.queryForObject(FIND_TITRE , mapParameterSource, new BeanPropertyRowMapper<>(Film.class))).getTitre();
	}
	/**
	 * Mise en place du RowMapper avec gestion de l'association 1-1
	 */
	class FilmRowMapper implements RowMapper<Film> {

		@Override
		public Film mapRow(ResultSet rs, int rowNum) throws SQLException {
			Film f = new Film();
			f.setId(rs.getLong("id_film"));
			f.setTitre(rs.getString("titre"));
			f.setAnnee(rs.getInt("annee"));
			f.setDuree(rs.getInt("duree"));
			f.setSynopsis(rs.getString("synopsis"));
			

			// Association film genre
			Genre g = new Genre();
			g.setId(rs.getLong("id_genre"));
			g.setTitre(rs.getString("titre_genre"));
			f.setGenre(g);
			
			// Association film Realisateur (Participant)
			Participant r = new Participant();
			r.setId(rs.getLong("id_realisateur"));
			r.setNom(rs.getString("nom"));
			r.setPrenom(rs.getString("prenom"));
			f.setRealisateur(r);
			
			System.out.println("sortie map row : " + f);
			
			
			return f;
		}
	}
}
