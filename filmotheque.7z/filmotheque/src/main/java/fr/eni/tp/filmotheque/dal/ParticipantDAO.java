package fr.eni.tp.filmotheque.dal;

import java.util.List;

import fr.eni.tp.filmotheque.bo.Participant;

public interface ParticipantDAO {
	Participant read(long id);
	List<Participant> findAll();
	List<Participant> findacteurs(long idFilm);
	Void createActeur(long idParticipant, long idFilm);

}
